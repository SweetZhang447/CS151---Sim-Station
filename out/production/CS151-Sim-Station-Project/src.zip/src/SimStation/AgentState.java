package SimStation;

// I don't think we need this now according to the new design- Can
public enum AgentState {
    READY, RUNNING, SUSPEND, STOPPED;
}
